V0.9.6
- Moved Agility to ID
  - Removed level setter for agility
- Simplified Level Cap Code

V0.9.5
- Skill interval reduction reduced (80% -> 50%)
- Reduced interference outside of Conquest Mode
- Bug: Skills are not auto showing anymore

V0.9.4
- Thieving, Cooking, and Summoning no longer locked behind Impending Darkness
 - Now locked behind Volcanic Cave
 - Does have a 99 level cap pre ID

V0.9.3b
- New Icon

V0.9.3
- Reduced Interval Cap to 50ms
- Reduced Slayer Task Roll Speed to 50ms
- Fixed Magic level cap
- Added bank slot scaling
  - When you beat a dungeon for the first time you may buy an additional bank slot; you unlock another after 3 clears, and yet another at 10
  - This is true for each dungeon

V0.9.2
- Added cap to bank slots from shop
- Fixed typo 'minning' -> 'mining'
- Arid Potato fix
- Updated rules
- Removed non-speedrun modes
- Added level caps to combat skills before ID
- Added Kill count after each monster
- Auto hides skills when appropriate

V0.9.1
- Permanently locked firemaking, woodcutting, fishing, agility, minning, and farming
- Added ctx patch to onCharacterLoad to set above skills to level 120
- Added check to see if gamemode is speedrun to reduce summon attack time to 200ms
- Doubled exp gains in speedrun modes
- Added semi-functional locked skill alert

V0.9.0
- Launch