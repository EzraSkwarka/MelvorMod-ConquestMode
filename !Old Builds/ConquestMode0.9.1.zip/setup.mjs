let forbidden_skills_Impending_Darkness = [
  "melvorD:Cooking",
  "melvorD:Smithing",
  "melvorD:Thieving",
  "melvorD:Crafting",
  "melvorD:Herblore",
  "melvorD:Summoning",
];
let forbidden_skills_Throne_of_the_Herald = [
  "melvorD:Astrology",
  "melvorD:Runecrafting",
  "melvorD:Fletching",
  "melvorD:Township",
];
let forbidden_skills = [
  "melvorD:Firemaking",
  "melvorD:Woodcutting",
  "melvorD:Fishing",
  "melvorD:Agility",
  "melvorD:Mining",
  "melvorD:Farming",
];


export async function setup(ctx) {
  const gamemodeJSON = await ctx.loadData("data/gamemode.json");

  ctx.onInterfaceReady(ctx => {
    //Skill view toggle, modified from tibalt-io's Hide Locked Skills
    toggleLockedSkills(sidebar.categories().find(c => c.id === 'Non-Combat').items(), true);
    ctx.patch(Enemy, "renderImageAndName").after(function () {
      if (this.state === EnemyState.Alive)
          //Display Kill count
          $(enemyHTMLElements.name)[0].append(" - " + game.stats.monsterKillCount(game.combat.selectedMonster));
          //Refresh Skill View after each kill
          toggleLockedSkills(sidebar.categories().find(c => c.id === 'Non-Combat').items(), true);
  })
  });

  //UNTESTED
  // ctx.patch(CombatEvent, "addDungeonCompletion").after(dungeon => {
  //   toggleLockedSkills(sidebar.categories().find(c => c.id === 'Non-Combat').items(), true);
  // })


  ctx.onCharacterLoaded((ctx) => {
    if (game.currentGamemode.id.includes("conquest")) {
      game.combat.player.summonAttackInterval = 200;
      //Set Levels to 120
      game.firemaking.setXP(exp.level_to_xp(120) + 1);
      game.woodcutting.setXP(exp.level_to_xp(120) + 1);
      game.fishing.setXP(exp.level_to_xp(120) + 1);
      game.agility.setXP(exp.level_to_xp(120) + 1);
      game.mining.setXP(exp.level_to_xp(120) + 1);
      game.farming.setXP(exp.level_to_xp(120) + 1); //could be in a loop i guess?
    }
  });


  //Restricts which skills can be unlocked
  ctx.patch(Skill, "unlockOnClick").replace(function () {
    if (this._unlocked) return;
    if (game.currentGamemode.id.includes("conquest")) {
      if (
        forbidden_skills_Impending_Darkness.includes(this.id) &&
        game.combat.getDungeonCompleteCount(
          game.dungeons.getObjectByID("melvorF:Impending_Darkness")
        ) < 1
      ) {
        beatDungeonAlert(this.id, "Impending Darkness");
        return;
      } else if (
        forbidden_skills_Throne_of_the_Herald.includes(this.id) &&
        game.combat.getDungeonCompleteCount(
          game.dungeons.getObjectByID("melvorTotH:Throne_of_the_Herald")
        ) < 1
      ) {
        beatDungeonAlert(this.id, "Throne of the Herald");
        return;
      } else if (forbidden_skills.includes(this.id)) {
        lockedSkillAlert(this.id);
        return;
      }
    }
  });

  //Double XP patch
  ctx.patch(Skill, "addXP").before(function (amount, masteryAction) {
    if (game.currentGamemode.id.includes("conquest")) {
      return [amount * 2, masteryAction];
    }
  });

  //Adds pre-ID level caps
  // Combat Level Caps before beating ID
  ctx.patch(Attack, 'levelCap').get((o) => {
    return levelCapbeforeID();
  })
  ctx.patch(Strength, 'levelCap').get((o) => {
    return levelCapbeforeID();
  })
  ctx.patch(Defence, 'levelCap').get((o) => {
    return levelCapbeforeID();
  })
  ctx.patch(Hitpoints, 'levelCap').get((o) => {
    return levelCapbeforeID();
  })
  ctx.patch(Ranged, 'levelCap').get((o) => {
    return levelCapbeforeID();
  })
  ctx.patch(AltMagic, 'levelCap').get((o) => {
    return levelCapbeforeID();
  })
  ctx.patch(Prayer, 'levelCap').get((o) => {
    return levelCapbeforeID();
  })
  ctx.patch(Slayer, 'levelCap').get((o) => {
    return levelCapbeforeID();
  })

  //Auto-eat Patch, pulled from Zxv's HCCO mod
  ctx.patch(Player, "autoEat").replace(function (o, foodSwapped) { // Fix autoeat potatoes in Arid Plains
    if ((this.hitpoints <= this.autoEatThreshold || foodSwapped) && this.food.currentSlot.item !== this.game.emptyFoodItem) {
      const autoEatHealing = Math.max(Math.floor((this.getFoodHealing(this.food.currentSlot.item) * this.autoEatEfficiency) / 100), 1); // This line is the fix
      let foodQty = Math.ceil((this.autoEatHPLimit - this.hitpoints) / autoEatHealing);
      foodQty = Math.min(foodQty, this.food.currentSlot.quantity);
      this.eatFood(foodQty, false, this.autoEatEfficiency);
      if (this.food.currentSlot.quantity < 1 && this.modifiers.autoSwapFoodUnlocked > 0 && this.game.settings.enableAutoSwapFood) {
        const nonEmptySlot = this.food.slots.findIndex((slot) => slot.item !== this.game.emptyFoodItem);
        if (nonEmptySlot >= 0) {
          this.food.setSlot(nonEmptySlot);
          if (this.hitpoints < this.autoEatHPLimit)
            this.autoEat(true);
        }
      }
    }
  })


}

//Helper functions for Level Caps
function levelCapbeforeID() {
  if (game.combat.getDungeonCompleteCount(
    game.dungeons.getObjectByID("melvorF:Impending_Darkness")) >= 1)
    return cloudManager.hasTotHEntitlement ? 120 : 99;
  else
    return 99;

}

//Helper fucntions for hiding skills
function lockedSkillItems(categoryItems) {
  const charSkills = Array.from(game.skills.registeredObjects);
  //if beat none
  if (
    game.combat.getDungeonCompleteCount(
      game.dungeons.getObjectByID("melvorF:Impending_Darkness")
    ) < 1
  ) {
    return categoryItems.filter(item =>
      charSkills.some(skill => skill[0] === item.id && skill[1]._unlocked === false && (forbidden_skills.includes(item.id) || forbidden_skills_Throne_of_the_Herald.includes(item.id) || forbidden_skills_Impending_Darkness.includes(item.id))));
  }
  //else if beat ID
  else if (
    game.combat.getDungeonCompleteCount(
      game.dungeons.getObjectByID("melvorTotH:Throne_of_the_Herald")
    ) < 1
  ) {
    return categoryItems.filter(item =>
      charSkills.some(skill => skill[0] === item.id && skill[1]._unlocked === false && (forbidden_skills.includes(item.id) || forbidden_skills_Throne_of_the_Herald.includes(item.id))));
  }
  //else if beat TOTH
  else if (
    game.combat.getDungeonCompleteCount(
      game.dungeons.getObjectByID("melvorTotH:Throne_of_the_Herald")
    ) < 1
  ) {
    return categoryItems.filter(item =>
      charSkills.some(skill => skill[0] === item.id && skill[1]._unlocked === false && (forbidden_skills.includes(item.id))));
  }
  //else
  return categoryItems.filter(item =>
    charSkills.some(skill => skill[0] === item.id && skill[1]._unlocked === false && forbidden_skills.includes(item.id)));
}

function toggleLockedSkills(categoryItems, hide) {
  // console.log("Toggleing Skill View")
  lockedSkillItems(categoryItems).forEach(item => {
    if (hide) {
      item.rootEl.classList.add('hidden');
      item.rootEl.setAttribute('aria-hidden', 'true');
    } else {
      item.rootEl.classList.remove('hidden');
      item.rootEl.removeAttribute('aria-hidden');
    }
  });
}

//Helper functions for allerting user
//TODO: Remove once the hide skills functionality is working
//@ts-ignore
function beatDungeonAlert(skill, requirement) {
  SwalLocale.fire({
    icon: "error",
    title: getLangString("MENU_TEXT", "SKILL_LOCKED"),
    html: `<span class='text-dark'>${templateString(
      "You need to beat ${dungeon} to unlock ${skillName}.",
      {
        skillName: skill.toString(),
        dungeon: requirement.toString(),
      }
    )}</span>`,
  });
}

function lockedSkillAlert(skill) {
  SwalLocale.fire({
    icon: "error",
    title: getLangString("MENU_TEXT", "SKILL_LOCKED"),
    html: `<span class='text-dark'>${templateString(
      "You are not able to unlock ${skillName} in conquest mode.",
      {
        skillName: skill.toString(),
      }
    )}</span>`,
  });
}