let forbidden_skills_Volcanic_Cave = [
  "melvorD:Thieving",
  "melvorD:Cooking",
  "melvorD:Summoning",
];

let forbidden_skills_Impending_Darkness = [
  "melvorD:Smithing",
  "melvorD:Agility",
  "melvorD:Crafting",
  "melvorD:Herblore",
];
let forbidden_skills_Throne_of_the_Herald = [
  "melvorD:Astrology",
  "melvorD:Runecrafting",
  "melvorD:Fletching",
  "melvorD:Township",
];
let forbidden_skills = [
  "melvorD:Firemaking",
  "melvorD:Woodcutting",
  "melvorD:Fishing",
  "melvorD:Mining",
  "melvorD:Farming",
];

export async function setup(ctx) {
  const gamemodeJSON = await ctx.loadData("data/gamemode.json");
  //Adds pre-ID level caps, Dont know why it needs to be out here to work?
  ctx.patch(Skill, "levelCap").get((o) => {
    if (game.currentGamemode.id.includes("conquest")) {
      return levelCapBeforeID();
    } else {
      return cloudManager.hasTotHEntitlement ? 120 : 99;
    }
  });

  ctx.onCharacterLoaded((ctx) => {
    console.log("Checking for Conquest Mode...");

    if (game.currentGamemode.id.includes("conquest")) {
      //Keeps the mod from breaching containment
      console.log("Applying Conquest Mode Patches");

      //Set summon attack Speed
      game.combat.player.summonAttackInterval = 200;
      //Set Levels to 120
      game.firemaking.setXP(exp.level_to_xp(120) + 1);
      game.woodcutting.setXP(exp.level_to_xp(120) + 1);
      game.fishing.setXP(exp.level_to_xp(120) + 1);
      game.mining.setXP(exp.level_to_xp(120) + 1);
      game.farming.setXP(exp.level_to_xp(120) + 1); //could be in a loop i guess?

      ctx.onInterfaceReady((ctx) => {
        //Skill view toggle, modified from tibalt-io's Hide Locked Skills
        toggleLockedSkills(
          sidebar
            .categories()
            .find((c) => c.id === "Non-Combat")
            .items(),
          true
        );

        //Kill count and Skill View
        ctx.patch(Enemy, "renderImageAndName").after(function () {
          if (this.state === EnemyState.Alive)
            //Display Kill count
            $(enemyHTMLElements.name)[0].append(
              " - " + game.stats.monsterKillCount(game.combat.selectedMonster)
            );
          //Refresh Skill View after each kill
          toggleLockedSkills(
            sidebar
              .categories()
              .find((c) => c.id === "Non-Combat")
              .items(),
            true
          );
        });
      });

      //Patch Bank slots
      ctx.patch(ShopPurchase, "getBuyLimit").after(function (limit) {
        let tracker = 0;
        game.dungeons.forEach((dungeon) => {
          let beatCount = game.combat.getDungeonCompleteCount(
            game.dungeons.getObjectByID(dungeon.id)
          );
          if (beatCount >= 10) {
            tracker += 3;
          } else if (beatCount >= 3) {
            tracker += 2;
          } else if (beatCount >= 1) {
            tracker += 1;
          }
        });
        // console.log("tracker: " + tracker);
        if (this.id === "melvorD:Extra_Bank_Slot") {
          limit = tracker;
        }
        return limit;
      });

      //Restricts which skills can be unlocked
      ctx.patch(Skill, "unlockOnClick").replace(function () {
        // console.log("Unlocked " + this.id);

        if (game.currentGamemode.id.includes("conquest")) {
          if (
            forbidden_skills_Volcanic_Cave.includes(this.id) &&
            game.combat.getDungeonCompleteCount(
              game.dungeons.getObjectByID("melvorD:Volcanic_Cave")
            ) < 1
          ) {
            beatDungeonAlert(this.id, "Impending Darkness");
            return;
          } else if (
            forbidden_skills_Impending_Darkness.includes(this.id) &&
            game.combat.getDungeonCompleteCount(
              game.dungeons.getObjectByID("melvorF:Impending_Darkness")
            ) < 1
          ) {
            beatDungeonAlert(this.id, "Impending Darkness");
            return;
          } else if (
            forbidden_skills_Throne_of_the_Herald.includes(this.id) &&
            game.combat.getDungeonCompleteCount(
              game.dungeons.getObjectByID("melvorTotH:Throne_of_the_Herald")
            ) < 1
          ) {
            beatDungeonAlert(this.id, "Throne of the Herald");
            return;
          } else if (forbidden_skills.includes(this.id)) {
            lockedSkillAlert(this.id);
            return;
          }
        }
        if (this._unlocked) return;
        const cost = this.game.getSkillUnlockCost();
        if (!this.game.gp.canAfford(cost)) return;
        this.game.gp.remove(cost);
        this.setUnlock(true);
        SwalLocale.fire({
          icon: "success",
          title: getLangString("MENU_TEXT", "SKILL_UNLOCKED"),
          html: `<span class='text-dark'>${getLangString(
            "MENU_TEXT",
            "YOU_MAY_USE_SKILL"
          )}</span>`,
        });
        sendPlayFabEvent("adv_skill_unlocked", {
          skillID: this.id,
          unlockOrder: this.game.getSkillUnlockCount(),
        });
      });

      //Double XP patch
      ctx.patch(Skill, "addXP").before(function (amount, masteryAction) {
        if (game.currentGamemode.id.includes("conquest")) {
          return [amount * 2, masteryAction];
        }
      });

      //Auto-eat Patch, pulled from Zxv's HCCO mod
      ctx.patch(Player, "autoEat").replace(function (o, foodSwapped) {
        // Fix autoeat potatoes in Arid Plains
        if (
          (this.hitpoints <= this.autoEatThreshold || foodSwapped) &&
          this.food.currentSlot.item !== this.game.emptyFoodItem
        ) {
          const autoEatHealing = Math.max(
            Math.floor(
              (this.getFoodHealing(this.food.currentSlot.item) *
                this.autoEatEfficiency) /
                100
            ),
            1
          ); // This line is the fix
          let foodQty = Math.ceil(
            (this.autoEatHPLimit - this.hitpoints) / autoEatHealing
          );
          foodQty = Math.min(foodQty, this.food.currentSlot.quantity);
          this.eatFood(foodQty, false, this.autoEatEfficiency);
          if (
            this.food.currentSlot.quantity < 1 &&
            this.modifiers.autoSwapFoodUnlocked > 0 &&
            this.game.settings.enableAutoSwapFood
          ) {
            const nonEmptySlot = this.food.slots.findIndex(
              (slot) => slot.item !== this.game.emptyFoodItem
            );
            if (nonEmptySlot >= 0) {
              this.food.setSlot(nonEmptySlot);
              if (this.hitpoints < this.autoEatHPLimit) this.autoEat(true);
            }
          }
        }
      });

      //Interval Caps
      ctx
        .patch(SkillWithMastery, "modifyInterval")
        .replace(function (o, interval, action) {
          const flatModifier = this.getFlatIntervalModifier(action);
          const percentModifier = this.getPercentageIntervalModifier(action);
          interval *= 1 + percentModifier / 100;
          interval += flatModifier;
          interval = roundToTickInterval(interval);
          return Math.max(interval, 50);
        });
      ctx.patch(Character, "computeAttackInterval").replace(function () {
        let attackInterval = this.equipmentStats.attackSpeed || 4000;
        attackInterval = this.modifyAttackInterval(attackInterval);
        attackInterval = roundToTickInterval(attackInterval);
        attackInterval = Math.max(attackInterval, 50);
        this.stats.attackInterval = attackInterval;
      });

      //Slayer Task Reroll Speed
      ctx
        .patch(SlayerTask, "selectTask")
        .replace(function (o, tier, costsCoins, render, fromClick = false) {
          const data = SlayerTask.data[tier];
          if (costsCoins && !this.game.slayerCoins.canAfford(data.cost)) {
            notifyPlayer(
              this.game.slayer,
              getLangString("TOASTS", "CANNOT_AFFORD_THAT"),
              "danger"
            );
          } else {
            const monsterSelection = this.getMonsterSelection(tier);
            if (monsterSelection.length > 0) {
              const newMonster =
                monsterSelection[rollInteger(0, monsterSelection.length - 1)];
              if (costsCoins) this.game.slayerCoins.remove(data.cost);
              this.monster = newMonster;
              this.tier = tier;
              this.active = false;
              this.autoStartNext = !fromClick;
              this.taskTimer.start(50); //this is the change
              this.renderRequired = true;
              this.renderNewButton = true;
            } else if (this.autoSlayer) {
              notifyPlayer(
                this.game.slayer,
                getLangString("TOASTS", "NO_TASK_FOUND_EQUIPMENT"),
                "danger"
              );
            } else {
              notifyPlayer(
                this.game.slayer,
                getLangString("TOASTS", "NO_TASK_FOUND_TIER"),
                "danger"
              );
            }
          }
          if (render) {
            this.render();
            this.clickNewTask();
          }
        });
    } else {
      console.log("Not in Conquest Mode.");
    }
  });
}

//Helper functions for Level Caps
function levelCapBeforeID() {
  let beatID = game.combat.getDungeonCompleteCount(
    game.dungeons.getObjectByID("melvorF:Impending_Darkness")
  );
  if (beatID >= 1) {
    return cloudManager.hasTotHEntitlement ? 120 : 99;
  } else {
    return 99;
  }
}

//Helper functions for hiding skills
function lockedSkillItems(categoryItems) {
  const charSkills = Array.from(game.skills.registeredObjects);
  //If beat none
  if (
    game.combat.getDungeonCompleteCount(
      game.dungeons.getObjectByID("melvorD:Volcanic_Cave")
    ) < 1
  ) {
    if (
      game.combat.getDungeonCompleteCount(
        game.dungeons.getObjectByID("melvorD:Volcanic_Cave")
      ) == 1
    )
      console.log("Volc at one");
    return categoryItems.filter((item) =>
      charSkills.some(
        (skill) =>
          skill[0] === item.id &&
          skill[1]._unlocked === false &&
          (forbidden_skills.includes(item.id) ||
            forbidden_skills_Throne_of_the_Herald.includes(item.id) ||
            forbidden_skills_Impending_Darkness.includes(item.id) ||
            forbidden_skills_Volcanic_Cave.includes(item.id))
      )
    );
  }
  //else if beat volcanic and not beat ID
  else if (
    game.combat.getDungeonCompleteCount(
      game.dungeons.getObjectByID("melvorF:Impending_Darkness")
    ) < 1
  ) {
    return categoryItems.filter((item) =>
      charSkills.some(
        (skill) =>
          skill[0] === item.id &&
          skill[1]._unlocked === false &&
          (forbidden_skills.includes(item.id) ||
            forbidden_skills_Throne_of_the_Herald.includes(item.id) ||
            forbidden_skills_Impending_Darkness.includes(item.id))
      )
    );
  }
  //else if beat ID and not ToTH
  else if (
    game.combat.getDungeonCompleteCount(
      game.dungeons.getObjectByID("melvorTotH:Throne_of_the_Herald")
    ) < 1
  ) {
    return categoryItems.filter((item) =>
      charSkills.some(
        (skill) =>
          skill[0] === item.id &&
          skill[1]._unlocked === false &&
          (forbidden_skills.includes(item.id) ||
            forbidden_skills_Throne_of_the_Herald.includes(item.id))
      )
    );
  }
  //else if beat TOTH
  else {
    return categoryItems.filter((item) =>
      charSkills.some(
        (skill) =>
          skill[0] === item.id &&
          skill[1]._unlocked === false &&
          forbidden_skills.includes(item.id)
      )
    );
  }
}

function toggleLockedSkills(categoryItems, hide) {
  console.log("Toggling Skill View");
  lockedSkillItems(categoryItems).forEach((item) => {
    if (hide) {
      item.rootEl.classList.add("hidden");
      item.rootEl.setAttribute("aria-hidden", "true");
    } else {
      item.rootEl.classList.remove("hidden");
      item.rootEl.removeAttribute("aria-hidden");
    }
  });
}

//Helper functions for allerting user
//TODO: Remove once the hide skills functionality is working
//@ts-ignore
function beatDungeonAlert(skill, requirement) {
  SwalLocale.fire({
    icon: "error",
    title: getLangString("MENU_TEXT", "SKILL_LOCKED"),
    html: `<span class='text-dark'>${templateString(
      "You need to beat ${dungeon} to unlock ${skillName}.",
      {
        skillName: skill.toString(),
        dungeon: requirement.toString(),
      }
    )}</span>`,
  });
}

function lockedSkillAlert(skill) {
  SwalLocale.fire({
    icon: "error",
    title: getLangString("MENU_TEXT", "SKILL_LOCKED"),
    html: `<span class='text-dark'>${templateString(
      "You are not able to unlock ${skillName} in conquest mode.",
      {
        skillName: skill.toString(),
      }
    )}</span>`,
  });
}
