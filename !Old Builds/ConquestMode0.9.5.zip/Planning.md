TODO:
- Find list of items not avalible to CO + skills i'm allowing
- Find a way to award mastery tokens for forbidden skills
- Find a way to disperse Marks and pets for forbidden skills
- Make forbidden skill skillcapes purchase-able
- ~~Move theiving and summoning behind Volc Cave~~ Done in V0.9.4